# Editorial Twin

What you get:
- static/ — Northbound Review landing (HTML/CSS)
- astro-twin/ — same page as Astro (source + dist/)
- TWIN-DIFF.md — static ↔ Astro parity notes

Open static/index.html or astro-twin/dist/index.html in a browser.
